﻿
using System;
using System.Linq;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Class1.Task1();

            Console.WriteLine();
            Console.WriteLine("-------");

            Class1.Task2();

            Console.WriteLine();
            Console.WriteLine("-------");

            Class1.Task3();

            Console.WriteLine();
            Console.WriteLine("-------");

            Class1.Task4();

            Console.WriteLine();
            Console.WriteLine("-------");

            Class1.Task5();

            Console.WriteLine();
            Console.WriteLine("-------");

            Class1.Task6();

            Console.WriteLine();
            Console.WriteLine("-------");

            Class1.Task7();

            Console.WriteLine();
            Console.WriteLine("-------");

            Class1.Task8();

            Console.ReadLine();
        }
    }
}
