﻿
using System;
using System.Data.SqlTypes;
using System.Linq;

namespace ConsoleApp1
{
    public static class Class1
    {

        public static void Task1()
        {
            int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 5, 2 };
            foreach (int element in array)
            {
                Console.Write(element); Console.Write(" ");
            }
            int even = array.Count(x => x % 2 == 0);
            int noteven = array.Count(x => x % 2 != 0);
            int uniq = array.Distinct().Count();
            int t = array.Count();
            uniq = t - uniq;
            Console.WriteLine($"Even: {even}, Not Even: {noteven},  Uniq: {uniq}");
        }

        public static void Task2()
        {
            int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 5, 2 };
            Console.WriteLine("Enter num: ");
            string s = Console.ReadLine();
            int.TryParse(s, out int t);
            int count = array.Count(x => x < t);
            Console.WriteLine($"Elemp<{t}: {count}");
        }

        public static void Task3()
        {
            int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 5, 2 };
            string s1 = Console.ReadLine();
            string s2 = Console.ReadLine();
            string s3 = Console.ReadLine();
            int.TryParse(s1, out int t1);
            int.TryParse(s2, out int t2);
            int.TryParse(s3, out int t3);
            int count = 0;

            for (int i = 0; i < array.Length - 3; i++)
            {
                if (array[i] == t1 & array[i + 1] == t2 & array[i + 2] == t3) count++;
            }
            Console.WriteLine($"Count: {count}");
        }

        public static void Task4()
        {
            int[] array1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 5, 2 };
            int[] array2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 5, 2, 2432, 123 };

            var array3 = array1.Concat(array2);
            array3 = array3.Distinct();
            foreach (int element in array3)
            {
                Console.Write(element); Console.Write(" ");
            }
        }

        public static void Task5()
        {
            int[] array1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 5, 2 };

            var min = array1.Min();
            var max = array1.Max();
            Console.WriteLine($"Min: {min}, Max: {max}");
        }

        public static void Task6()
        {
            Console.WriteLine("Input sentense:");
            string sentence = Console.ReadLine();

            string[] words = sentence.Split(new char[] { ' ', '.', ',', '!', '?', ';', ':', '-', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            int wordCount = words.Length;
            Console.WriteLine($"Count of words in the sentense: {wordCount}");
        }

        public static void Task7()
        {
            Console.WriteLine("Input:");
            string sentence = Console.ReadLine();

            string[] words = sentence.Split(' ');


            for (int i = 0; i < words.Length; i++)
            {
                char[] charArray = words[i].ToCharArray();
                Array.Reverse(charArray);
                words[i] = new string(charArray);
            }

            Console.WriteLine($"After reverse: {string.Join(" ", words)}");
        }

        public static void Task8()
        {
            Console.WriteLine("Enter a sentence :");
            string sentence = Console.ReadLine();

            int vowelCount = 0;

            
            foreach (char c in sentence)
            {
                if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
                    c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U')
                {
                    vowelCount++;
                }
            }

            Console.WriteLine($"The number of vowels in the sentence: {vowelCount}");
        }
    }
}

